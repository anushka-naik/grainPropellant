from flask import Flask, render_template, redirect, url_for, request
import math
import matplotlib
matplotlib.use('Agg') 
import matplotlib.pyplot as plt
import seaborn as sns
import os
import sys
import numpy as np
from itertools import product
import math
from math import pi
import pandas as pd
import time
import os

def df_crossjoin(df1, df2, **kwargs):
    df1['_tmpkey'] = ''
    df2['_tmpkey'] = ''

    res = pd.merge(df1, df2, on='_tmpkey', **kwargs).drop('_tmpkey', axis=1)
    res.index = pd.MultiIndex.from_product((df1.index, df2.index))

    df1.drop('_tmpkey', axis=1, inplace=True)
    df2.drop('_tmpkey', axis=1, inplace=True)

    return res

def getVolume(l,d,di,nh,a,p,n, br, STEP_SIZE):
    vols = []
    maxU = (d-di)/2
#     time_to_burn = (r-ri)/br
    i = 0
    u = 2 * br * i
    vol = pi/4 * ( (d-u)**2 - nh*(di+u)**2) * (l - u)
    
    while(u < maxU and vol>0):
        vol = pi/4 * ( (d-u)**2 - nh*(di+u)**2) * (l - u)
        vols.append(vol)
        i += STEP_SIZE 
        u = 2 * br * i
    return vols

def getSA(l,d,di,nh,a,p,n, br, STEP_SIZE):
    sas = []
    maxU = (d-di)/2
    i = 0
    u = 2 * br * i
    while(u < maxU):
        sa = pi * ( ( (d-u) + nh*(di + u)) * (l - u) + ((d-u)**2 - nh*(di+u)**2)/2)
        sas.append(sa)
        i += STEP_SIZE 
        u = 2 * br * i
        #how is the volume increasing?
    return sas

app = Flask(__name__)

# @app.route('/<name>')
# def index(name):
#     return render_template("index.html", boy = name)

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/report', methods=['POST', 'GET'])
def report():
    if request.method == 'POST':
        
        D = float(request.form.get('D'))
        d = float(request.form.get('d'))
        n = int(request.form.get('n')) #num of holes
        L = float(request.form.get('L'))
        z=  float(request.form.get('z'))
        a = float(request.form.get('a'))
        p = float(request.form.get('p'))
        N = float(request.form.get('N'))
        report = request.form

        vols=[]
        sas=[]
        steps = []
        br = a*p**N
        maxU=(D-d)/2
        i=0
        u=2*br*i
        vol= math.pi/4 * ( (D-u)**2 - n*(d+u)**2) * (L - u)
        while(u < maxU and vol>0):
            vol = math.pi/4 * ( (D-u)**2 - n*(d+u)**2) * (L - u)
            vols.append(float(vol))
            
            sa = math.pi * ( ( (D-u) + n*(d + u)) * (L - u) + ((D-u)**2 - n*(d+u)**2)/2)
            sas.append(sa)
            
            i += z 
            u = 2 * br * i
            steps.append(i)

               
        plt.figure()
        plt.plot(steps, vols)
        plt.title("Vols vs Time")
        plt.xlabel("Time")
        plt.ylabel("Volume")
        # plt.legend()
        plt.savefig('static/images/Volume.png')
        
        plt.figure()
        plt.plot(steps, sas)
        plt.title("Surface Area vs Time")
        plt.xlabel("Time")
        plt.ylabel("Surface Area")
        # plt.legend()
        plt.savefig('static/images/Surface Area.png')
        
        os.chdir(os.getcwd())
        figs = os.listdir('static/images')
        figs = ['images/' + file for file in figs]
        
        # return redirect(url_for('showVar', varName = D))  
        
        sns.reset_defaults()
        sns.set(
            rc={'figure.figsize':(7,5)}, 
            style="white" # nicer layout
        )
        
        fig = sns.lineplot(x=steps, y = vols).get_figure()
        fig.savefig("del.png")
       
        
        return render_template("report.html", report=report, figs = figs)
    
    
    
    
    
    
    else:
        D = request.args.get('D')
        return render_template("index.html")
        # return redirect(url_for('showVar', varName =D))

@app.route('/createDB')
def createDB():
    return render_template("createDB.html")

@app.route('/databaseReport',methods=['POST', 'GET'])
def databaseReport():
    if request.method == "POST":
        report = request.form
        Dstart  = float(report['Dstart'])
        Dend    = float(report['Dend'])
        Dstep   = float(report['Dstep'])
        Distart  = float(report['Distart'])
        Diend    = float(report['Diend'])
        Distep   = float(report['Distep'])
        Gstart  = float(report['Gstart'])
        Gend    = float(report['Gend'])
        Gstep   = float(report['Gstep'])
        astart  = float(report['astart'])
        aend    = float(report['aend'])
        astep   = float(report['astep'])
        Pstart  = float(report['Pstart'])
        Pend    = float(report['Pend'])
        Pstep   = float(report['Pstep'])
        Nstart  = float(report['Nstart'])
        Nend    = float(report['Nend'])
        Nstep   = float(report['Nstep'])
        Nhstart  = float(report['Nhstart'])
        Nhend    = float(report['Nhend'])
        Nhstep   = float(report['Nhstep'])
        # VolStep = float(report['VolStep'])
        # SAStep = float(report['SAStep'])
        
        
        d = np.arange(Dstart, Dend, Dstep)
        l = np.arange(Gstart, Gend, Gstep)
        di = np.arange(Distart, Diend, Distep)
        nh = np.arange(Nhstart, Nhend, Nhstep) #number of holes
        a = np.arange(astart, aend, astep)
        p = np.arange(Pstart, Pend, Pstep)
        n = np.arange(Nstart, Nend, Nstep)
              
        #DEMO CODE WITH ANY INPUT IS HERE
        
        # d = np.arange(2,10,1)
        # di = np.arange(1,8,1)
        # l= np.arange(2,100,2)
        # nh = np.arange(1,39, 2) #number of holes
        # a = np.arange(1,5,1)
        # p = np.arange(20,100,5)
        # n = np.arange(1,7,1)

        dfx = df_crossjoin(pd.DataFrame(l, columns = ['l']), pd.DataFrame(d, columns = ['d'])).droplevel(1)
        dfx = df_crossjoin(dfx, pd.DataFrame(di, columns = ['di'])).droplevel(1)
        dfx = df_crossjoin(dfx, pd.DataFrame(nh, columns = ['nh'])).droplevel(1)
        dfx = df_crossjoin(dfx, pd.DataFrame(a, columns = ['a'])).droplevel(1)

        dfx.to_csv("temp.csv", index=False)

        # print(dfx.head())

        df_iterator = pd.read_csv('temp.csv', 
                            dtype={'l' : float, 'd':float, 'di':float, 'nh':float, 'a':float}, 
                            chunksize=1e6, 
                            # header = None, 
                            on_bad_lines='skip')

        for i, df in enumerate(df_iterator):
            dfx = df_crossjoin(df, pd.DataFrame(p, columns = ['p'])).droplevel(1)
            mode = 'w' if i == 0 else 'a' 
            header = i == 0
            dfx.columns = ['l','d','di', 'nh', 'a', 'p']
            dfx[1:].to_csv("temp.csv", 
                    mode= mode,
                    header = header, 
                    index = False)
            
        df = pd.read_csv("temp.csv")
        df.head()

        df_iterator = pd.read_csv('temp.csv', 
                            dtype={'l' : float, 'd':float, 'di':float, 'nh':float, 'a':float, 'p':float}, 
                            chunksize=1e6, 
                            # header = None, 
                            on_bad_lines='skip')

        for i, df in enumerate(df_iterator):
            
            dfx = df_crossjoin(df[1:], pd.DataFrame(n, columns = ['n'])).droplevel(1)
            mode = 'w' if i == 0 else 'a'
            header = i == 0
            dfx.columns = ['l','d','di', 'nh', 'a', 'p', 'n']
            dfx[1:].to_csv("Database.csv", 
                    mode= mode,
                    header = header, 
                    index = False)

        # df_iterator = pd.read_csv('temp.csv', 
        #                             dtype={'l' : float, 'd':float, 'di':float, 'nh':float, 'a':float, 'p':float, 'n':float},
        #                             chunksize=1e6,
        #                             # header = 0,
        #                             on_bad_lines='skip')


        # for i, df in enumerate(df_iterator):
            
        #     df['br'] = df.a * df.p**df.n
        #     df['InitVolume'] = pi/4 * (df.d**2 -df.nh*df.di**2) * df.l
        #     df['InitSA'] = pi*((df.d + df.nh*df.di)*df.l + (df.d**2 - df.nh*df.di**2)/2)
            
        #     df['Volumes'] = ''
        #     df['SurfaceAreas'] = ''
            
        #     # print("chktp1", sys.stdout)
        #     for index, row in df.iterrows():
        #         df.at[index, 'Volumes'] = getVolume(row.l, row.d, row.di, row.nh, row.a, row.p, row.n, row.br, VolStep)
        #         df.at[index, 'SurfaceAreas'] = getSA(row.l, row.d, row.di, row.nh, row.a, row.p, row.n, row.br, SAStep)
        #         # print("anything done?", file = sys.stdout)
        #     # print("chktp2", sys.stdout)
        #     mode = 'w' if i == 0 else 'a'
        #     header = i == 0
            
        #     # df.to_csv(
        #     #     "dataset.csv",
        #     #     index=False,  # Skip index column
        #     #     header=header, 
        #     #     mode=mode)

        #     df.to_csv(
        #         "dataset.csv.gz",
        #         index=False,  # Skip index column
        #         header=header, 
        #         mode=mode,
        #         compression='gzip')
        #     print("Program is on the {} iteration".format(i), file = sys.stdout)

        return render_template("databaseReport.html")




# @app.route('/showVar/<varName>')
# def showVar(varName):
#     return 'Var name is: ' + str(varName)

if __name__ == "__main__":
    app.run(debug=True, port=5001)
